<?php

class Objava
{

    protected  $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

public function getObjavaSlike()
{
    $sql = "SELECT 
            objava_slika.id AS objava_id,
            objava_slika.naziv_url,
            objava_slika.datum,
            objava_slika.naslov,
            objava_slika.tekst,
            MIN(slika.fotografija) AS prva_slika
        FROM 
            objava_slika
        LEFT JOIN 
            slika ON objava_slika.id = slika.objava_id
        WHERE 
            objava_slika.obrisan=0
        GROUP BY 
            objava_slika.id, objava_slika.naziv_url, objava_slika.datum, objava_slika.naslov, objava_slika.tekst;";

    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $objave = [];
    $stmt->bind_result($objava_id, $naziv_url, $datum, $naslov, $tekst, $prva_slika);
    while ($stmt->fetch()) {
        $objave[] = [
            'objava_id' => $objava_id,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'prva_slika' => $prva_slika,
        ];
    }

    $stmt->close();

    return $objave;
}


    public function getObjavaVideoLimit()
    {
        $sql = "SELECT * FROM objava_videa, video WHERE objava_videa.id = video.objava_id ORDER BY objava_videa.id DESC LIMIT 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();

        $result = $stmt->get_result();

        return $result->fetch_all(MYSQLI_ASSOC);
    }

public function getObjavaSlikeByUrl($naziv_url)
{
    $sql = "SELECT * FROM objava_slika, slika WHERE objava_slika.id = slika.objava_id AND objava_slika.naziv_url=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $naziv_url);
    $stmt->execute();

    $images = [];
    $stmt->bind_result($id, $naziv_url, $datum, $naslov, $tekst, $objava_id, $fotografija);  // Dodajte kolone prema vašoj tabeli
    while ($stmt->fetch()) {
        $images[] = [
            'id' => $id,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'objava_id' => $objava_id,
            'fotografija' => $fotografija,
        ];
    }

    $stmt->close();

    return $images;
}


public function getLastPhotos()
{
    $sql = "SELECT * FROM objava_slika WHERE obrisan=0 ORDER BY datum DESC LIMIT 3";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $photos = [];
    $stmt->bind_result($id, $naziv_url, $datum, $naslov, $tekst, $obrisan);
    while ($stmt->fetch()) {
        $photos[] = [
            'id' => $id,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'obrisan' => $obrisan
        ];
    }

    $stmt->close();

    return $photos;
}


public function getAllVideos()
{
    $sql = "SELECT * FROM objava_videa WHERE obrisan=0";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();
    
    // Store the result set
    $stmt->store_result();

    // Bind the result variables (prilagodi prema strukturi tabele)
    $stmt->bind_result($id, $video, $cover, $naziv_url, $datum, $naslov, $tekst, $obrisan); 

    $videos = [];

    // Fetch the results into the array
    while ($stmt->fetch()) {
        $videos[] = [
            'id' => $id,
            'video' => $video,
            'cover' => $cover,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'obrisan' => $obrisan
        ];
    }

    return $videos;
}


public function getVideoByUrl($naziv_url)
{
    $sql = "SELECT * FROM objava_videa WHERE naziv_url=? AND obrisan=0";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $naziv_url);
    $stmt->execute();

    $video = [];
    $stmt->bind_result($id, $video, $cover, $naziv_url, $datum, $naslov, $tekst, $obrisan);
    if ($stmt->fetch()) {
        $video = [
            'id' => $id,
            'video' => $video,
            'cover' => $cover,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'obrisan' => $obrisan
        ];
    }

    $stmt->close();

    return $video;
}


public function getLastVideos()
{
    $sql = "SELECT * FROM objava_videa WHERE obrisan=0 ORDER BY id DESC LIMIT 3";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $videos = [];
    $stmt->bind_result($id, $video, $cover, $naziv_url, $datum, $naslov, $tekst,$obrisan);  
    while ($stmt->fetch()) {
        $videos[] = [
            'id' => $id,
            'video' => $video,
            'cover' => $cover,
            'naziv_url' => $naziv_url,
            'datum' => $datum,
            'naslov' => $naslov,
            'tekst' => $tekst,
            'obrisan' => $obrisan
        ];
    }

    $stmt->close();

    return $videos;
}


    public function createUrl($string)
    {
        $string = strtolower($string);
        $string = preg_replace('/[^a-z0-9]+/', '-', $string);
        $string = trim($string, '-');

        return $string;
    }

    public function addPhotos($objava_id, $fotografija)
    {
        $sql = "INSERT INTO slika(objava_id, fotografija) VALUES (?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $objava_id, $fotografija);
        $stmt->execute();
    }

    public function addPost($naziv_url, $datum, $naslov, $tekst)
    {
        $sql = "INSERT INTO objava_slika (naziv_url, datum, naslov, tekst) VALUES (?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssss", $naziv_url, $datum, $naslov, $tekst);
        $stmt->execute();
    }

    public function addVideo($video, $cover, $naziv_url, $datum, $naslov, $tekst)
    {
        $sql = "INSERT INTO objava_videa(video, cover, naziv_url, datum, naslov, tekst) VALUES (?,?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssss", $video, $cover, $naziv_url, $datum, $naslov, $tekst);
        $stmt->execute();
    }

    public function deleteSlike($id)
    {
        $sql = "UPDATE objava_slika SET obrisan=1 WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    public function deleteVidea($id)
    {
        $sql = "UPDATE objava_videa SET obrisan=1 WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

public function countPhoto()
{
    $sql = "SELECT COUNT(id) AS total FROM objava_slika WHERE obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $stmt->bind_result($total);
    $stmt->fetch();

    $stmt->close();

    return ['total' => $total];
}


public function countVideo()
{
    $sql = "SELECT COUNT(id) AS total FROM objava_videa WHERE obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $stmt->bind_result($total);
    $stmt->fetch();

    $stmt->close();

    return ['total' => $total];
}

}
