<?php

class Proizvod
{
    protected  $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function createUrl($string)
    {
        $string = strtolower($string);
        $string = preg_replace('/[^a-z0-9]+/', '-', $string);
        $string = trim($string, '-');

        return $string;
    }

    public function editProduct($naziv, $naziv_url, $kategorija, $tip, $opis, $istaknut, $delovanje_preparata, $primena_preparata, $rezultati_ogleda, $fotografija, $timestamp, $id)
    {
        $sql = "UPDATE proizvod SET naziv=?, naziv_url=?, kategorija=?, tip=?, opis=?, istaknut=?, delovanje_preparata=?, primena_preparata=?, rezultati_ogleda_tekst=?, fotografija=?, timestamp=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssisssssi", $naziv, $naziv_url, $kategorija, $tip, $opis, $istaknut, $delovanje_preparata, $primena_preparata, $rezultati_ogleda, $fotografija, $timestamp, $id);
        $stmt->execute();
    }

    public function addProduct($naziv, $naziv_url, $kategorija, $tip, $opis, $istaknut, $delovanje_preparata, $primena_preparata, $rezultati_ogleda, $fotografija, $timestamp)
    {
        $sql = "INSERT INTO proizvod (naziv, naziv_url, kategorija, tip, opis, istaknut, delovanje_preparata, primena_preparata, rezultati_ogleda_tekst, fotografija, timestamp) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssisssss", $naziv, $naziv_url, $kategorija, $tip, $opis, $istaknut, $delovanje_preparata, $primena_preparata, $rezultati_ogleda, $fotografija, $timestamp);
        $stmt->execute();
    }

    public function deleteProduct($id)
    {
        $sql = "UPDATE proizvod SET obrisan=1 WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i",$id);
        $stmt->execute();
    }

    public function addPhotos($proizvod_id, $fotografija)
    {
        $sql = "INSERT INTO rezultati_ogleda_slike(proizvod_id, fotografija) VALUES (?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $proizvod_id, $fotografija);
        $stmt->execute();
    }

    public function addBaner($fotografija, $pozicija) {
        $sql = "UPDATE baner SET fotografija=? WHERE pozicija=?";
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            echo "<script>alert('Greška pri pripremi: " . htmlspecialchars($this->conn->error) . "');</script>";
            return false;
        }
        
        $stmt->bind_param("ss", $fotografija, $pozicija);
        
        if (!$stmt->execute()) {
            echo "<script>alert('Greška pri izvršavanju: " . htmlspecialchars($stmt->error) . "');</script>";
            return false;
        }
    
        if ($stmt->affected_rows > 0) {
            return true; // Uspešno
        } else {
            echo "<script>alert('Nije izvršena nijedna promena. Proverite da li pozicija postoji.');</script>";
            return false; // Neuspešno
        }
    }
    

    public function deletePhotoById($id)
    {
        $sql = "DELETE FROM rezultati_ogleda_slike WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

public function getProductByCategory($kategorija)
{
    $sql = "SELECT * FROM proizvod WHERE kategorija=? AND obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $kategorija);
    $stmt->execute();
    
    // Store the result set
    $stmt->store_result();

    // Bind the result variables
    $stmt->bind_result($id, $naziv, $naziv_url, $kategorija, $tip, $fotografija, $opis, $delovanje_preparata, $primena_preparata, $rezultati_ogleda_tekst, $istaknut, $timestamp, $obrisan); 

    $products = [];

    // Fetch the results into the array
    while ($stmt->fetch()) {
        $products[] = [
            'id' => $id,
            'naziv' => $naziv,
            'naziv_url' => $naziv_url,
            'kategorija' => $kategorija,
            'tip' => $tip,
            'fotografija' => $fotografija,
            'opis' => $opis,
            'delovanje_preparata' => $delovanje_preparata,
            'primena_preparata' => $primena_preparata,
            'rezultati_ogleda_tekst' => $rezultati_ogleda_tekst,
            'istaknut' => $istaknut,
            'timestamp' => $timestamp,
            'obrisan' => $obrisan
        ];
    }

    return $products;
}

public function getProductByUrl($naziv_url)
{
    $sql = "SELECT * FROM proizvod WHERE naziv_url=? AND obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $naziv_url);
    $stmt->execute();

    $result = [];
    $stmt->bind_result($id, $naziv, $naziv_url, $kategorija, $tip, $fotografija, $opis, $delovanje_preparata, $primena_preparata, $rezultati_ogleda_tekst, $istaknut, $timestamp, $obrisan);
    if ($stmt->fetch()) {
        $result = [
            'id' => $id,
            'naziv' => $naziv,
            'naziv_url' => $naziv_url,
            'kategorija' => $kategorija,
            'tip' => $tip,
            'fotografija' => $fotografija,
            'opis' => $opis,
            'delovanje_preparata' => $delovanje_preparata,
            'primena_preparata' => $primena_preparata,
            'rezultati_ogleda_tekst' => $rezultati_ogleda_tekst,
            'istaknut' => $istaknut,
            'timestamp' => $timestamp,
            'obrisan' => $obrisan

        ];
    }

    $stmt->close();

    return $result;
}


public function getBanerByPosition($pozicija)
{
    $sql = "SELECT * FROM baner WHERE pozicija=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $pozicija);
    $stmt->execute();
    
    // Store the result set
    $stmt->store_result();

    // Bind the result variables
    $stmt->bind_result($id, $pozicija, $fotografija); 

    // Fetch the result
    $banner = null;
    if ($stmt->fetch()) {
        $banner = [
            'id' => $id,
            'pozicija' => $pozicija,
            'fotografija' => $fotografija

        ];
    }

    return $banner;
}


public function getPhotosById($id)
{
    $sql = "SELECT * FROM rezultati_ogleda_slike WHERE proizvod_id=? AND obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $photos = [];
    $stmt->bind_result($id, $proizvod_id, $fotografija, $obrisan);  // Dodajte kolone prema vašoj tabeli
    while ($stmt->fetch()) {
        $photos[] = [
            'id' => $id,
            'proizvod_id' => $proizvod_id,
            'fotografija' => $fotografija,
            'obrisan' => $obrisan
        ];
    }

    $stmt->close();

    return $photos;
}



public function getBannerByPosition($pozicija)
{
    $sql = "SELECT * FROM baner WHERE pozicija=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $pozicija);
    $stmt->execute();

    $banner = [];
    $stmt->bind_result($id, $pozicija, $link, $opis, $obrisan);  // Dodajte kolone prema vašoj tabeli
    if ($stmt->fetch()) {
        $banner = [
            'id' => $id,
            'pozicija' => $pozicija,
            'link' => $link,
            'opis' => $opis,
            'obrisan' => $obrisan
        ];
    }

    $stmt->close();

    return $banner;
}

public function getCatalogName()
{
    $sql = "SELECT id, katalog FROM katalog";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    $stmt->bind_result($id, $katalog);
    $stmt->fetch();

    $stmt->close();

    $row = ['id' => $id, 'katalog' => $katalog];

    if ($row && isset($row['katalog'])) {
        $row['katalog'] = basename($row['katalog']);
    }

    return $row;
}


public function getCatalog()
{
    $sql = "SELECT * FROM katalog";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();
    
    // Store the result set
    $stmt->store_result();

    // Bind the result variables
    $stmt->bind_result($id, $katalog, $fotografija); // Prilagodi prema strukturi tabele 'katalog'

    $catalog = [];

    // Fetch the results into the array
    while ($stmt->fetch()) {
        $catalog[] = [
            'id' => $id,
            'katalog' => $katalog,
            'fotografija' => $fotografija
        ];
    }

    // Return the first element or null if empty
    return !empty($catalog) ? $catalog[0] : null;
}


    public function updateCatalog($katalog, $fotografija, $id)
    {
        $katalogPath = "./assets/img/katalog/" . $katalog;
        $fotografijaPath = "./assets/img/katalog/" . $fotografija;
        $sql = "UPDATE katalog SET katalog=?, fotografija=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssi", $katalogPath, $fotografijaPath, $id);
        $stmt->execute();
    }

public function getProductsIstaknuti()
{
    $sql = "SELECT * FROM proizvod WHERE istaknut='1' AND obrisan='0'";
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();
    
    // Store the result set
    $stmt->store_result();

    // Bind the result variables
    $stmt->bind_result($id, $naziv, $naziv_url, $kategorija, $tip, $fotografija, $opis, $delovanje_preparata, $primena_preparata, $rezultati_ogleda_tekst,$istaknut,  $timestamp, $obrisan); 

    $products = [];

    // Fetch the results into the array
    while ($stmt->fetch()) {
        $products[] = [
            'id' => $id,
            'naziv' => $naziv,
            'naziv_url' => $naziv_url,
            'kategorija' => $kategorija,
            'tip' => $tip,
            'fotografija' => $fotografija,
            'opis' => $opis,
            'delovanje_preparata' => $delovanje_preparata,
            'primena_preparata' => $primena_preparata,
            'rezultati_ogleda_tekst' => $rezultati_ogleda_tekst,
            'istaknut' => $istaknut,
            'timestamp' => $timestamp,
            'obrisan' => $obrisan
        ];
    }

    return $products;
}


public function countProductbyCategory($kategorija)
{
    $sql = "SELECT COUNT(id) AS total FROM proizvod WHERE obrisan='0' AND kategorija=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("s", $kategorija);
    $stmt->execute();

    $stmt->bind_result($total);
    $stmt->fetch();

    $stmt->close();

    // Vraćamo rezultat kao asocijativni niz
    return ['total' => $total];
}

}

?>
